const a="/build/assets/avatar-1-129659bb.png";export{a};
