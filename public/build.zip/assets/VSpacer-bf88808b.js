import{c as e}from"./VAvatar-c5c5c70f.js";const a=e("flex-grow-1","div","VSpacer");export{a as V};
