import{c as e}from"./VAvatar-08392dd6.js";const a=e("flex-grow-1","div","VSpacer");export{a as V};
