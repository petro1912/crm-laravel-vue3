import{c as e}from"./VAvatar-76d73489.js";const a=e("flex-grow-1","div","VSpacer");export{a as V};
