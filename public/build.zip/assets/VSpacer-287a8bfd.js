import{c as e}from"./VAvatar-8d1777e9.js";const a=e("flex-grow-1","div","VSpacer");export{a as V};
